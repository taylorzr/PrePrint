/* TODO
    Landscape
*/

//< Menu
app.addMenuItem({
    cName: 'Tab Cropper',
    cParent: submenu_name,
    cExec: "tabCropper()"
});

//< Code
function tabCropper()
{
	count = 0; // Records the number of tabs
	for (i=0;i<this.numPages;i++)
	{
		page_size = this.getPageBox({nPage: i}); //Current Page Size
		tab_size = [0,792,648,0];
		// Javascript can't compare arrays directly...
		if (page_size.toString()==tab_size.toString())
		{
			//Crop 1/2" from left side
			this.setPageBoxes({cBox:"Crop", nStart:i, rBox:[36,792,648,0]});
			count++;
		}
	}
	if (count==0)
	{
		app.alert("No tabs were detected.");
    } 
	else 
	{
		app.alert(count + " Tabs were cropped!");
	}
}	