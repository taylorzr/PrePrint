function inserter(pages, path, position){
    if (position=='before') position = -2;
    else position = -1;
    
    for (i=pages.length-1; i>=0; i--){
        this.insertPages({
            cPath: path,
            nPage: (pages[i]+position),
            nStart: i
        });
    }
}

inserter([1,3,5], '/c/Tabs.pdf');