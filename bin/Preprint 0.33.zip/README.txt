INSTALLATION:
    1. Copy all the javascript files to: "%appdata%\Adobe\Acrobat\Privileged\10.0\JavaScripts"
       a. Go to the start menu, hit run, paste the above directory and hit OK, then copy & paste files
       b. If the directory does not exist, create it
    
    2. Restart Acrobat
    
    3. Done. You should now see a submenu "Preprint" under the "Window" Menu
    
    
More information on acrobat scripting is available from Adobe @
https://www.adobe.com/devnet/acrobat/pdfs/js_api_reference.pdf


CHANGES:
v 0.33, 6-14-14
Changed menu settings to work with Acrobat 10

v 0.32, 6-27-12
Added beta poster size calculator. Added slipsheet finder. Fixed slight bug in tab finder displaying ampersand

v 0.31
Added italic, bold and bold italic versions of Helvetica and Times New Roman
Updated scripts to check for open document before execution

v 0.3
Fixed bug in tabber roman numeral list

v 0.2
Added tabber autofill ability