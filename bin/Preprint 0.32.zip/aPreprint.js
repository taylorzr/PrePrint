// Acrobat all javascript files alphabetically. This needs to load first!

//< Menu
    submenu_name = "Preprint"
    app.addSubMenu({
		cName: submenu_name,
		cParent: "Tools"
	});        	