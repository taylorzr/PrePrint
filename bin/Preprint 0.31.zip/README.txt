INSTALLATION:
    1. Copy all the javascript files to: "%appdata%\Adobe\Acrobat\8.0\JavaScripts"
       a. Go to the start menu, hit run, paste the above directory and hit OK, then copy & paste files
       b. If you get a directory error, change the version number in the path (i.e. 8.0 -> 7.0)
    
    2. Restart Acrobat
    
    3. Done. You should now see a submenu "Preprint" under the "Tools" Menu
    
    
More information on acrobat scripting is available from Adobe @
https://www.adobe.com/devnet/acrobat/pdfs/js_api_reference.pdf


CHANGES:
v 0.31
Added italic, bold and bold italic versions of Helvetica and Times New Roman
Updated scripts to check for open document before execution

v 0.3
Fixed bug in tabber roman numeral list

v 0.2
Added tabber autofill ability